﻿using System.ComponentModel.DataAnnotations;

namespace MPArbitration.Model
{
    /// <summary>
    /// Entity to hadle entity master data's
    /// </summary>
    public class DisputeMasterEntity
    {
        /// <summary>
        /// Used to hold entity
        /// </summary>
        public string? Entity { get; set; }
    }
}
