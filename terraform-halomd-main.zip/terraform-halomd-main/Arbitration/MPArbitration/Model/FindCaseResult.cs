﻿namespace MPArbitration.Model
{
    public class FindCaseResult
    {
        public string Message { get; set; } = "";
        public ArbitrationCase? Record { get; set; } = null;
    }
}
