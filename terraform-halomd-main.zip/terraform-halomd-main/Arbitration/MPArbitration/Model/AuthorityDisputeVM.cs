﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace MPArbitration.Model
{
    /*
    public class AuthorityDisputeVM : AuthorityDispute
    {
        
    }
    */
}
