export enum AuthorityCalculatorOption
{
    Default,
    PercentOfCharges,
    PercentOfLookup
}
