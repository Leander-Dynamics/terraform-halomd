export enum FeeType {
    Administrative,
    BatchSize,
    ClaimSize,
    PerItem,
    PerClaim
}
