import { ToastEnum } from "./toast-enum";

export interface AlertInfo {
    message: string;
    type: string;
}
