export interface IName {
    name:string;
}

export interface IPatientInfo {
    patientName:string;
}

export interface IKeyId {
    id:number;
    key:string;
}
