export interface IArbitrationCase {
    arbitrationCaseId:number;
}
