export enum NotificationType {
    NSANegotiationRequest = 0,
    NSANegotiationRequestAttachment  = 1,
    StateBrief = 2,
    StateBriefComponent = 3,
    IDRBrief = 4,
    IDRBriefComponent = 5,
    Other = 98,
    Unknown = 99
}
