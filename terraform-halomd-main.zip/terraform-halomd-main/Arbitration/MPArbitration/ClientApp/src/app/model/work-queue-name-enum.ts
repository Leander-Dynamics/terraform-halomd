export enum WorkQueueName
{
    None = 0,
    DisputeBriefPreparer = 1,
    DisputeBriefWriter = 2,
    DisputeBriefApprover = 3,
    All = 99
}
