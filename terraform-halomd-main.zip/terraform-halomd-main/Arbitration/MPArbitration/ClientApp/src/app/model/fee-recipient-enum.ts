export enum FeeRecipient {
    Arbitrator,
    Authority
}
