/*
export class AuthorityStats {
    public key = '';
    public active = 0;
    public ineligible = 0;
    public notSubmitted = 0;
    public paid = 0;
    public settledFormal = 0;
    public settledInformal = 0;
    public unpaid = 0;
}
*/
