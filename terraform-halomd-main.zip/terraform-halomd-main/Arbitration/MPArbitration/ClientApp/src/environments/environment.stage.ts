export const environment = {
  production: true,
  appVersion: require('../../package.json').version + '-stage',
  redirectUrl: 'https://arbitration-stage.mpowerhealth.com',
  clientId: 'feb1fc35-5267-4946-bc23-d8da34237e90',
  tenantName: '2e09f3a3-0520-461f-8474-052a8ed7814a'
};
