﻿namespace MPExternalDisputeAPI.Model
{
    public class ImportDataSynchronizer : IImportDataSynchronizer
    {
    }
}
