﻿namespace MPExternalDisputeAPI.Model
{
    public interface IImportDataSynchronizer
    {
    }
}
