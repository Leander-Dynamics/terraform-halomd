export interface IEHRKey
{
    DOB:Date|undefined;
    providerNPI:string;
    patientName:string;
    payorClaimNumber:string;
    serviceDate:Date|undefined;
}