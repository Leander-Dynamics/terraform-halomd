export interface IModifier {
    updatedBy: string;
    updatedOn: Date|undefined;
}