export enum ArbitratorType {
    Arbitrator,
    CertifiedEntity,
    Facilitator,
    Mediator
}