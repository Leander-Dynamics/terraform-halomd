export enum ToastEnum {
    danger,
    info,
    success,
    warning
}