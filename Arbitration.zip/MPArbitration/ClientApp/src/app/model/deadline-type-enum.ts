export enum DeadlineType {
    CalendarDays,
    WorkDays
}