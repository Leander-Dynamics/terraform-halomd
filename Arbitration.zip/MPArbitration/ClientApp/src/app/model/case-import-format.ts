export interface ICaseImportFormat {
    ehr:string;
    columns:number;
    id:number;
    value:string;
}