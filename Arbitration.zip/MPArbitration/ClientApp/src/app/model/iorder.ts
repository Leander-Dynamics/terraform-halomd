export interface IOrder {
    order:number;
}