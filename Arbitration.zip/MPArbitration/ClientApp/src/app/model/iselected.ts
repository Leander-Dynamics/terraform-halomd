export interface ISelected {
    isSelected:boolean;
}